from Flota import menu_ventana
print("Bienvenido al sistema de flota de vehículos")

menu_ventana()

